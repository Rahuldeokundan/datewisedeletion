from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from azure.cosmos import CosmosClient, PartitionKey
from azure.storage.blob import BlockBlobService, PublicAccess
import requests
import urllib.request
from urllib.error import HTTPError
import json
import os
from pathlib import Path
# Create your views here.

endpoint = 'https://sncosmosdb.documents.azure.com:443/'
key = 'ulYE2KTm8REkmTx4BbVUmfscUErNV0uNyShLAa6A3vB1B5iRkDLF0CTJ6I4KBXlQUTQT3HXMIgZqtuZvg6uxRA=='

client = CosmosClient(endpoint, key)
database = client.create_database_if_not_exists(id='sn-repo')

container_name = 'sn-mdm'
container = database.create_container_if_not_exists(
    id=container_name,
    partition_key=PartitionKey(path="/api"),
    offer_throughput=400
)

query = "SELECT * FROM c "

items = list(container.query_items(
    query=query,
    enable_cross_partition_query=True
))

def fetch_svc(request):
    # Start Connection

    # End Connection
    # Start Well Filter
    result = {}
    for item in items:
        if item['pad'] in result:
            wells = result[item['pad']]
            if item['well_name'] not in wells:
                wells.append(item['well_name'])
        else:
            wells = []
            wells.append(item['well_name'])
            result[item['pad']] = wells
        # print(result)
    # End Well Filter

    # Start API Filter

    result_api = {}
    for item in items:
        if item['well_name'] in result_api:
            wells = result_api[item['well_name']]

            if item['api'] not in wells:
                wells.append(item['api'])
        else:
            wells = []
            wells.append(item['api'])
            result_api[item['well_name']] = wells
    # End API Filter

    # Start Data Fetching
    if request.method == 'POST':
        start_date = request.POST['start_date']
        start_time = request.POST['start_time']
        end_date = request.POST['end_date']
        end_time = request.POST['end_time']
        #refresh_point = request.POST['refresh_point']
        well_item = request.POST.getlist('well_names')

        # To use request package in current program
        date_to=start_date+" "+start_time
        date_from=end_date+" "+end_time

        dates= 'startdate='+start_date+" "+start_time+'&enddate='+end_date+" "+end_time
        print(dates)

        url_delete=('https://sndeletejsondate.azurewebsites.net/api/JsonHttpTrigger1?'+dates)
        response = requests.get(url_delete)
        # if url_delete.status_code == 200:
        #     print('Success')
        # print(response.url_delete)



        # Start API Validation with Well Name
        api_list = {}
        for x in well_item:
            if x in result_api:
                for keys, values in result_api.items():
                    if x == keys:
                        api_list.update(api=values)
        api_list.update(date_to=date_to)
        api_list.update(date_from=date_from)
        #api_list.update(well_item=well_item)
        #api_list.update(refresh_point=refresh_point)
        api_list.update(processed = "false")
        # End API Validation with Well Name

        print(api_list)

        api_list={'list':api_list}
        # Serializing json

        blob_service_client = BlockBlobService(
            account_name='snazdl', account_key='+pgM4wsppBXuM2q2RTUjoziKjx2+WVJ7ShYuHQzCH9BY77uS4mxOXfjligO6yVUd+dOV0asuJ3UDj6q5gqg5gQ==')
        container_name = 'sn-points/refreshed'

        local_path = './refreshed'
        local_file_name = "refreshed.json"
        upload_file_path = os.path.join(local_path, local_file_name)
        print(upload_file_path)

        # Write text to the file
        with open(upload_file_path, 'a') as file:
            file.write(json.dumps(api_list))
        file.close()
#
#
#
#         # Writing to sample.json
#         # with open("./refreshed/refreshpoint.json", "a") as outfile:
#         #     outfile.write(json_object)
#
        # Create a blob client using the local file name as the name for the blob
        blob_client = blob_service_client.create_blob_from_path(container_name, local_file_name, upload_file_path)

        print("\nUploading to Azure Storage as blob:\n\t" + local_path)
#
# #

    return render(request, 'index.html', {'result': result})


