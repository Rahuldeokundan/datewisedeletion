from django.db import models
from django.conf import settings


# Create your models here.
class Wells(models.Model):
    Pad_ns = models.CharField(max_length=200)
    Well_ns = models.CharField(max_length=200)

    def __str__(self):
        return self.Pad_ns